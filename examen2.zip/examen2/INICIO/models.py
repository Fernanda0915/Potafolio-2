from django.db import models

class Ciudad(models.Model):
    nombre = models.CharField(max_length=100)

class Equipo(models.Model):
    nombre = models.CharField(max_length=100)
    ciudad = models.ForeignKey(Ciudad, on_delete=models.CASCADE)

class Estadio(models.Model):
    nombre = models.CharField(max_length=100)

class EquipoEstadio(models.Model):
    equipo = models.ForeignKey(Equipo, on_delete=models.CASCADE)
    estadio = models.ForeignKey(Estadio, on_delete=models.CASCADE)
