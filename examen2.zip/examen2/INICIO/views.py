from django.shortcuts import render
from .models import Ciudad, Equipo, Estadio, EquipoEstadio

def lista_equipos(request):
    equipos = Equipo.objects.all()
    return render(request, 'lista_equipos.html', {'equipos': equipos})

def lista_ciudades(request):
    ciudades = Ciudad.objects.all()
    return render(request, 'lista_ciudades.html', {'ciudades': ciudades})

def lista_estadios(request):
    estadios = Estadio.objects.all()
    return render(request, 'lista_estadios.html', {'estadios': estadios})

def equipo_en_estadio(request, equipo_id):
    equipo = Equipo.objects.get(pk=equipo_id)
    estadio = EquipoEstadio.objects.get(equipo=equipo).estadio
    return render(request, 'equipo_en_estadio.html', {'equipo': equipo, 'estadio': estadio})

def equipos_en_ciudad(request, ciudad_id):
    ciudad = Ciudad.objects.get(pk=ciudad_id)
    equipos = Equipo.objects.filter(ciudad=ciudad)
    return render(request, 'equipos_en_ciudad.html', {'ciudad': ciudad, 'equipos': equipos})
